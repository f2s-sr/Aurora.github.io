# AetherVein

**Innovative Attention Mining Platform**

AetherVein is a full-stack dark-crypto themed platform where users extract **"Vein Energy"** by completing cognitive micro-tasks.  
Your referral network becomes a living constellation that accelerates your personal mining speed.

> ⚠️ This is a **demo / educational project**.  
> No real money, no real payouts, no real blockchain.

---

## Concept

- Users complete micro-tasks (attention-based work)
- Each completed task generates **Vein Energy**
- Referral system creates a visual constellation network
- The more active your referral tree → the higher your temporal mining boost
- Pure dark cyber / crypto aesthetic

---

## Tech Stack

| Layer       | Technology                          |
|-------------|-------------------------------------|
| Frontend    | Next.js 14 + TypeScript + Tailwind  |
| Backend     | Python FastAPI                      |
| Database    | PostgreSQL + SQLAlchemy + Alembic   |
| Auth        | JWT                                 |
| Styling     | Dark Crypto Theme                   |

---

## Project Structure

```
AetherVein/
├── frontend/               # Next.js application
│   ├── src/
│   │   ├── app/            # App router pages
│   │   ├── components/     # React components
│   │   ├── lib/            # Utilities & API client
│   │   └── styles/         # Global styles
│   └── package.json
├── backend/                # FastAPI application
│   ├── app/
│   │   ├── api/            # Routes
│   │   ├── core/           # Config, security
│   │   ├── models/         # SQLAlchemy models
│   │   ├── schemas/        # Pydantic schemas
│   │   └── services/       # Business logic
│   ├── requirements.txt
│   └── main.py
└── README.md
```

---

## Features

- [x] Dark crypto UI (obsidian + neon accents)
- [x] User registration & JWT authentication
- [x] Task system (complete tasks → earn Vein Energy)
- [x] Multi-level referral system
- [x] Mining simulation with temporal boost from referrals
- [x] Referral constellation visualization (concept)
- [x] User dashboard with stats
- [x] Basic admin endpoints

---

## Getting Started

### 1. Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Configure your database in .env
cp .env.example .env

# Run
uvicorn main:app --reload
```

API docs available at: http://localhost:8000/docs

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open: http://localhost:3000

---

## Environment Variables

### Backend (`.env`)
```env
DATABASE_URL=postgresql://user:password@localhost:5432/aethervein
SECRET_KEY=your-super-secret-key-change-this
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
```

---

## License

MIT – Educational / Demo use only.
