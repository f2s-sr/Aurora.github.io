import axios from "axios";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";

const api = axios.create({
  baseURL: API_URL,
});

// Attach token if exists
api.interceptors.request.use((config) => {
  if (typeof window !== "undefined") {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

export default api;

// Auth
export const register = (data: { email: string; username: string; password: string; referral_code?: string }) =>
  api.post("/auth/register", data);

export const login = (email: string, password: string) => {
  const form = new URLSearchParams();
  form.append("username", email);
  form.append("password", password);
  return api.post("/auth/login", form, {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  });
};

// User
export const getMe = () => api.get("/users/me");
export const getMiningStatus = () => api.get("/users/me/mining");
export const claimMining = () => api.post("/users/me/claim-mining");
export const getReferralStats = () => api.get("/users/me/referrals");

// Tasks
export const getTasks = () => api.get("/tasks/");
export const completeTask = (taskId: number) => api.post(`/tasks/${taskId}/complete`);
