import type { Metadata } from "next";
import "../styles/globals.css";

export const metadata: Metadata = {
  title: "AetherVein — Attention Mining",
  description: "Extract temporal energy through cognitive tasks and referral networks",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-void-950 text-slate-200 antialiased">
        {children}
      </body>
    </html>
  );
}
