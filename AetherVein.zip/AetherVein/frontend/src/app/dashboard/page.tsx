"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  getMe,
  getMiningStatus,
  claimMining,
  getReferralStats,
  getTasks,
  completeTask,
} from "@/lib/api";
import { Zap, Users, CheckCircle, Activity, LogOut, Copy } from "lucide-react";

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [mining, setMining] = useState<any>(null);
  const [referrals, setReferrals] = useState<any>(null);
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [message, setMessage] = useState("");

  const loadData = async () => {
    try {
      const [meRes, miningRes, refRes, tasksRes] = await Promise.all([
        getMe(),
        getMiningStatus(),
        getReferralStats(),
        getTasks(),
      ]);
      setUser(meRes.data);
      setMining(miningRes.data);
      setReferrals(refRes.data);
      setTasks(tasksRes.data);
    } catch {
      localStorage.removeItem("token");
      router.push("/");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      router.push("/");
      return;
    }
    loadData();
  }, []);

  const handleClaim = async () => {
    setClaiming(true);
    try {
      const res = await claimMining();
      setMessage(res.data.message + (res.data.earned ? ` +${res.data.earned} VE` : ""));
      await loadData();
    } catch (err: any) {
      setMessage(err.response?.data?.detail || "Error claiming");
    } finally {
      setClaiming(false);
      setTimeout(() => setMessage(""), 3000);
    }
  };

  const handleCompleteTask = async (taskId: number) => {
    try {
      const res = await completeTask(taskId);
      setMessage(`Task completed! +${res.data.reward_earned.toFixed(2)} VE`);
      await loadData();
    } catch (err: any) {
      setMessage(err.response?.data?.detail || "Error");
    }
    setTimeout(() => setMessage(""), 3000);
  };

  const copyCode = () => {
    if (referrals?.referral_code) {
      navigator.clipboard.writeText(referrals.referral_code);
      setMessage("Referral code copied!");
      setTimeout(() => setMessage(""), 2000);
    }
  };

  const logout = () => {
    localStorage.removeItem("token");
    router.push("/");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-vein-400 animate-pulse">Loading Vein data...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-void-950">
      {/* Header */}
      <header className="border-b border-void-800 bg-void-900/50 backdrop-blur sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold bg-gradient-to-r from-vein-400 to-neon-cyan bg-clip-text text-transparent">
            AetherVein
          </h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-400">@{user?.username}</span>
            <button onClick={logout} className="text-slate-500 hover:text-white transition">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 space-y-8">
        {message && (
          <div className="bg-vein-600/20 border border-vein-500/40 text-vein-300 px-4 py-3 rounded-xl text-sm text-center">
            {message}
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <StatCard
            icon={<Zap className="w-5 h-5 text-vein-400" />}
            label="Vein Energy"
            value={user?.vein_energy?.toFixed(2) ?? "0.00"}
          />
          <StatCard
            icon={<Activity className="w-5 h-5 text-neon-cyan" />}
            label="Effective Rate"
            value={`${mining?.effective_rate?.toFixed(2) ?? "1.00"}/h`}
          />
          <StatCard
            icon={<Users className="w-5 h-5 text-neon-pink" />}
            label="Referrals"
            value={referrals?.total_referrals ?? 0}
          />
          <StatCard
            icon={<CheckCircle className="w-5 h-5 text-neon-green" />}
            label="Total Earned"
            value={user?.total_earned?.toFixed(2) ?? "0.00"}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Mining Panel */}
          <div className="lg:col-span-1 card-glow bg-void-900 border border-void-700 rounded-2xl p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Zap className="w-5 h-5 text-vein-400" /> Mining
            </h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-400">Base Rate</span>
                <span>{mining?.mining_rate?.toFixed(2)} VE/h</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Temporal Boost</span>
                <span className="text-vein-400">×{mining?.temporal_boost?.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Pending</span>
                <span className="text-neon-cyan">{mining?.pending_energy?.toFixed(4)} VE</span>
              </div>
            </div>
            <button
              onClick={handleClaim}
              disabled={claiming}
              className="mt-6 w-full py-3 rounded-xl bg-gradient-to-r from-vein-600 to-vein-500 hover:from-vein-500 hover:to-vein-400 font-medium transition disabled:opacity-50"
            >
              {claiming ? "Claiming..." : "Claim Mining Rewards"}
            </button>
          </div>

          {/* Referral Panel */}
          <div className="lg:col-span-1 card-glow bg-void-900 border border-void-700 rounded-2xl p-6">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-neon-pink" /> Constellation
            </h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Your Code</span>
                <button
                  onClick={copyCode}
                  className="flex items-center gap-1 font-mono text-vein-400 hover:text-vein-300"
                >
                  {referrals?.referral_code} <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total Referrals</span>
                <span>{referrals?.total_referrals}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Active</span>
                <span className="text-neon-green">{referrals?.active_referrals}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Bonus Earned</span>
                <span>{referrals?.total_bonus_earned?.toFixed(2)} VE</span>
              </div>
            </div>
            <p className="mt-4 text-xs text-slate-500">
              Share your code. Active referrals increase your temporal boost.
            </p>
          </div>

          {/* Quick info */}
          <div className="lg:col-span-1 card-glow bg-void-900 border border-void-700 rounded-2xl p-6">
            <h2 className="text-lg font-semibold mb-4">How it works</h2>
            <ul className="space-y-3 text-sm text-slate-400">
              <li className="flex gap-2">
                <span className="text-vein-400">01</span>
                Complete cognitive tasks to earn Vein Energy
              </li>
              <li className="flex gap-2">
                <span className="text-vein-400">02</span>
                Mining runs passively — claim anytime
              </li>
              <li className="flex gap-2">
                <span className="text-vein-400">03</span>
                Invite others → increase your temporal boost
              </li>
              <li className="flex gap-2">
                <span className="text-vein-400">04</span>
                Higher boost = faster energy extraction
              </li>
            </ul>
          </div>
        </div>

        {/* Tasks */}
        <div className="card-glow bg-void-900 border border-void-700 rounded-2xl p-6">
          <h2 className="text-lg font-semibold mb-6 flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-neon-green" /> Available Tasks
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tasks.map((task) => (
              <div
                key={task.id}
                className="bg-void-800/60 border border-void-700 rounded-xl p-4 hover:border-vein-600/40 transition"
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-medium text-sm">{task.title}</h3>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      task.difficulty === "easy"
                        ? "bg-green-500/20 text-green-400"
                        : task.difficulty === "medium"
                        ? "bg-yellow-500/20 text-yellow-400"
                        : "bg-red-500/20 text-red-400"
                    }`}
                  >
                    {task.difficulty}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mb-4 line-clamp-2">{task.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-vein-400 font-mono text-sm">+{task.reward} VE</span>
                  <button
                    onClick={() => handleCompleteTask(task.id)}
                    className="text-xs px-3 py-1.5 rounded-lg bg-vein-600/30 hover:bg-vein-600/50 text-vein-300 transition"
                  >
                    Complete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="card-glow bg-void-900 border border-void-700 rounded-2xl p-5">
      <div className="flex items-center gap-3 mb-2">
        {icon}
        <span className="text-xs text-slate-500 uppercase tracking-wider">{label}</span>
      </div>
      <p className="text-2xl font-semibold font-mono">{value}</p>
    </div>
  );
}
