"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { login, register } from "@/lib/api";
import { Zap, Network, Brain } from "lucide-react";

export default function HomePage() {
  const router = useRouter();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (isLogin) {
        const res = await login(email, password);
        localStorage.setItem("token", res.data.access_token);
        router.push("/dashboard");
      } else {
        await register({ email, username, password, referral_code: referralCode || undefined });
        const res = await login(email, password);
        localStorage.setItem("token", res.data.access_token);
        router.push("/dashboard");
      }
    } catch (err: any) {
      setError(err.response?.data?.detail || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-vein-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-10">
          <h1 className="text-5xl font-bold tracking-tight glow-text bg-gradient-to-r from-vein-400 to-neon-cyan bg-clip-text text-transparent">
            AetherVein
          </h1>
          <p className="mt-3 text-slate-400 text-sm tracking-wide">
            Extract temporal energy through attention
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          {[
            { icon: Brain, label: "Cognitive Tasks" },
            { icon: Zap, label: "Vein Energy" },
            { icon: Network, label: "Constellation" },
          ].map((item) => (
            <div key={item.label} className="flex flex-col items-center gap-2 p-3 rounded-xl bg-void-800/60 border border-vein-700/20">
              <item.icon className="w-5 h-5 text-vein-400" />
              <span className="text-xs text-slate-400">{item.label}</span>
            </div>
          ))}
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="card-glow bg-void-900/80 backdrop-blur border border-vein-700/20 rounded-2xl p-6 space-y-4">
          <div className="flex gap-2 mb-2">
            <button
              type="button"
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition ${
                isLogin ? "bg-vein-600 text-white" : "text-slate-400 hover:text-white"
              }`}
            >
              Login
            </button>
            <button
              type="button"
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition ${
                !isLogin ? "bg-vein-600 text-white" : "text-slate-400 hover:text-white"
              }`}
            >
              Register
            </button>
          </div>

          {!isLogin && (
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-void-800 border border-void-700 focus:border-vein-500 outline-none text-sm"
              required
            />
          )}

          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-void-800 border border-void-700 focus:border-vein-500 outline-none text-sm"
            required
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-void-800 border border-void-700 focus:border-vein-500 outline-none text-sm"
            required
          />

          {!isLogin && (
            <input
              type="text"
              placeholder="Referral Code (optional)"
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-void-800 border border-void-700 focus:border-vein-500 outline-none text-sm"
            />
          )}

          {error && (
            <p className="text-red-400 text-sm text-center">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-vein-600 to-vein-500 hover:from-vein-500 hover:to-vein-400 text-white font-medium transition disabled:opacity-50 shadow-glow"
          >
            {loading ? "Processing..." : isLogin ? "Enter the Vein" : "Create Account"}
          </button>
        </form>

        <p className="text-center text-xs text-slate-600 mt-6">
          Demo project • No real money involved
        </p>
      </div>
    </div>
  );
}
