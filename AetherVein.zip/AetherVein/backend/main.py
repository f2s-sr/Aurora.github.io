from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.database import engine, Base
from app.api import auth, users, tasks
from app.models.user import Task  # ensure models are loaded
from sqlalchemy.orm import Session
from app.core.database import SessionLocal

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    openapi_url=f"{settings.API_V1_STR}/openapi.json"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(users.router, prefix=settings.API_V1_STR)
app.include_router(tasks.router, prefix=settings.API_V1_STR)


@app.on_event("startup")
def seed_tasks():
    """Seed some default tasks if none exist"""
    db: Session = SessionLocal()
    try:
        count = db.query(Task).count()
        if count == 0:
            default_tasks = [
                Task(title="Verify Neural Pattern", description="Identify the correct pattern sequence", reward=8.0, difficulty="easy"),
                Task(title="Calibrate Attention Node", description="Focus and validate the signal", reward=12.0, difficulty="medium"),
                Task(title="Extract Temporal Fragment", description="Capture a fragment of time energy", reward=18.0, difficulty="medium"),
                Task(title="Stabilize Vein Flux", description="Balance the energy flow", reward=15.0, difficulty="hard"),
                Task(title="Scan Referral Constellation", description="Map a small sector of the network", reward=10.0, difficulty="easy"),
                Task(title="Deep Entropy Reduction", description="Advanced cognitive compression task", reward=25.0, difficulty="hard"),
            ]
            db.add_all(default_tasks)
            db.commit()
            print("Seeded default tasks.")
    finally:
        db.close()


@app.get("/")
def root():
    return {
        "project": "AetherVein",
        "tagline": "Extract temporal energy through attention",
        "docs": "/docs",
        "status": "online"
    }
