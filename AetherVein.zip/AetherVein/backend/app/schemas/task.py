from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class TaskBase(BaseModel):
    title: str
    description: Optional[str] = None
    reward: float
    difficulty: str = "easy"


class TaskCreate(TaskBase):
    pass


class TaskResponse(TaskBase):
    id: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class TaskCompletionResponse(BaseModel):
    id: int
    task_id: int
    reward_earned: float
    completed_at: datetime
    task: TaskResponse

    class Config:
        from_attributes = True
