from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import datetime


class UserBase(BaseModel):
    email: EmailStr
    username: str = Field(..., min_length=3, max_length=50)


class UserCreate(UserBase):
    password: str = Field(..., min_length=6)
    referral_code: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(UserBase):
    id: int
    vein_energy: float
    total_earned: float
    mining_rate: float
    temporal_boost: float
    referral_code: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    user_id: Optional[int] = None


class MiningStatus(BaseModel):
    vein_energy: float
    mining_rate: float
    temporal_boost: float
    effective_rate: float
    last_mining_at: datetime
    pending_energy: float


class ReferralStats(BaseModel):
    referral_code: str
    total_referrals: int
    active_referrals: int
    total_bonus_earned: float
