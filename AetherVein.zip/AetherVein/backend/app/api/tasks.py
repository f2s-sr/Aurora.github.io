from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.user import User, Task, TaskCompletion, Transaction
from app.schemas.task import TaskResponse, TaskCompletionResponse
from app.core.config import settings
import random

router = APIRouter(prefix="/tasks", tags=["Tasks"])


@router.get("/", response_model=List[TaskResponse])
def list_tasks(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    tasks = db.query(Task).filter(Task.is_active == True).all()
    return tasks


@router.post("/{task_id}/complete", response_model=TaskCompletionResponse)
def complete_task(
    task_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    task = db.query(Task).filter(Task.id == task_id, Task.is_active == True).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    # Check if already completed recently (simple anti-spam: once per task for demo)
    already = db.query(TaskCompletion).filter(
        TaskCompletion.user_id == current_user.id,
        TaskCompletion.task_id == task_id
    ).first()
    if already:
        raise HTTPException(status_code=400, detail="You already completed this task")

    # Apply temporal boost to reward
    final_reward = task.reward * current_user.temporal_boost

    completion = TaskCompletion(
        user_id=current_user.id,
        task_id=task.id,
        reward_earned=final_reward
    )
    db.add(completion)

    current_user.vein_energy += final_reward
    current_user.total_earned += final_reward

    # Transaction log
    tx = Transaction(
        user_id=current_user.id,
        amount=final_reward,
        type="task_reward",
        description=f"Completed task: {task.title}"
    )
    db.add(tx)

    # Simple referral bonus (level 1)
    if current_user.referred_by_id:
        referrer = db.query(User).filter(User.id == current_user.referred_by_id).first()
        if referrer:
            bonus = final_reward * settings.REFERRAL_BONUS_PERCENT
            referrer.vein_energy += bonus
            referrer.total_earned += bonus
            
            bonus_tx = Transaction(
                user_id=referrer.id,
                amount=bonus,
                type="referral_bonus",
                description=f"Referral bonus from {current_user.username}"
            )
            db.add(bonus_tx)

            # Small temporal boost increase
            referrer.temporal_boost = min(referrer.temporal_boost + 0.01, 3.0)

    db.commit()
    db.refresh(completion)
    return completion
