from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.api.deps import get_current_user
from app.models.user import User, Transaction
from app.schemas.user import UserResponse, MiningStatus, ReferralStats
from datetime import datetime, timezone

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    return current_user


@router.get("/me/mining", response_model=MiningStatus)
def get_mining_status(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc)
    last = current_user.last_mining_at.replace(tzinfo=timezone.utc) if current_user.last_mining_at.tzinfo is None else current_user.last_mining_at
    
    hours_passed = (now - last).total_seconds() / 3600
    effective_rate = current_user.mining_rate * current_user.temporal_boost
    pending = hours_passed * effective_rate

    return {
        "vein_energy": current_user.vein_energy,
        "mining_rate": current_user.mining_rate,
        "temporal_boost": current_user.temporal_boost,
        "effective_rate": effective_rate,
        "last_mining_at": current_user.last_mining_at,
        "pending_energy": round(pending, 4)
    }


@router.post("/me/claim-mining")
def claim_mining(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc)
    last = current_user.last_mining_at.replace(tzinfo=timezone.utc) if current_user.last_mining_at.tzinfo is None else current_user.last_mining_at
    
    hours_passed = (now - last).total_seconds() / 3600
    effective_rate = current_user.mining_rate * current_user.temporal_boost
    earned = hours_passed * effective_rate

    if earned < 0.01:
        return {"message": "Nothing to claim yet", "earned": 0}

    current_user.vein_energy += earned
    current_user.total_earned += earned
    current_user.last_mining_at = now

    # Record transaction
    tx = Transaction(
        user_id=current_user.id,
        amount=earned,
        type="mining",
        description=f"Claimed {earned:.4f} Vein Energy from mining"
    )
    db.add(tx)
    db.commit()

    return {
        "message": "Mining rewards claimed",
        "earned": round(earned, 4),
        "new_balance": round(current_user.vein_energy, 4)
    }


@router.get("/me/referrals", response_model=ReferralStats)
def get_referral_stats(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    referrals = db.query(User).filter(User.referred_by_id == current_user.id).all()
    active = [r for r in referrals if r.is_active]
    
    # Calculate bonus earned from referrals (simplified)
    bonus_txs = db.query(Transaction).filter(
        Transaction.user_id == current_user.id,
        Transaction.type == "referral_bonus"
    ).all()
    total_bonus = sum(tx.amount for tx in bonus_txs)

    return {
        "referral_code": current_user.referral_code,
        "total_referrals": len(referrals),
        "active_referrals": len(active),
        "total_bonus_earned": total_bonus
    }
