from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    PROJECT_NAME: str = "AetherVein"
    VERSION: str = "0.1.0"
    API_V1_STR: str = "/api/v1"

    DATABASE_URL: str = "postgresql://postgres:password@localhost:5432/aethervein"
    SECRET_KEY: str = "change-this-super-secret-key-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    BACKEND_CORS_ORIGINS: List[str] = ["http://localhost:3000"]

    # Mining economy
    BASE_MINING_RATE: float = 1.0          # Vein Energy per hour base
    TASK_REWARD_MIN: float = 5.0
    TASK_REWARD_MAX: float = 25.0
    REFERRAL_BONUS_PERCENT: float = 0.10   # 10% of referred user earnings
    MAX_REFERRAL_LEVELS: int = 3

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
